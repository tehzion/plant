# Solana Tec Smart Solar Calculator

## Overview

Solana Tec Smart Solar Calculator is a WordPress plugin for **Domestic Tariff A** residential estimates in Johor and Melaka. It uses the February 2026 NEM/ATAP rate structure to show:

- Estimated system size based on single-phase or three-phase supply
- Monthly solar generation
- Self-consumption versus export to grid
- Monthly, annual, and 25-year savings projections
- Payback period estimates

Version: 2.0.6  
Author: Mojo Digital

## What This Release Supports

- Domestic Tariff A only
- Locations: Johor Bahru, Batu Pahat, Kluang, Muar, Melaka, Johor (Other Areas)
- Payment methods: Cash, Loan, Credit Installment
- Optional lead capture before calculation
- Admin dashboard, lead management, and CSV export

## What This Release Does Not Include

- Commercial or industrial tariff flows
- Public diagnostic pages or verification scripts
- Public test shortcodes

## Installation

1. Upload the `nem-calculator` folder to `/wp-content/plugins/`.
2. Activate the plugin from **Plugins** in WordPress admin.
3. Add `[nem_calculator]` to a page or post.
4. Open **Solana Tec > Settings** to configure colors, lead capture, and CTA options.

## Usage

Users complete four required inputs:

1. Monthly electricity bill
2. Location
3. Payment method
4. Voltage level

The calculator then returns estimated savings and charts based on the current NEM/ATAP rates.

## Requirements

- WordPress 5.0 or newer
- PHP 7.2 or newer
- A theme that allows standard shortcode rendering

## Support Notes

- Chart rendering depends on Chart.js loading from CDN.
- Optional lead fields are stored with the calculation if provided.
- Invalid or expired AJAX nonce requests are rejected.
