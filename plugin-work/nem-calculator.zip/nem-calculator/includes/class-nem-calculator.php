<?php
/**
 * Main NEM Calculator Class
 * Version 1.1 - Enhanced with real TNB rates, peak/off-peak, and solar irradiance data
 */

class NEM_Calculator {
    
    private $tariff_groups;
    private $tnb_rates;
    private $solar_irradiance;
    
    public function __construct() {
        $this->init_tariff_groups();
        $this->init_tnb_rates();
        $this->init_solar_irradiance();
        add_action('wp_ajax_nem_calculate', array($this, 'calculate_nem'));
        add_action('wp_ajax_nopriv_nem_calculate', array($this, 'calculate_nem'));
    }
    
    private function init_solar_irradiance() {
        // Average daily solar irradiance (kWh/m²/day) by location in Malaysia
        // Based on Malaysian Meteorological Department data
        $this->solar_irradiance = array(
            'johor_bahru' => array(
                'name' => 'Johor Bahru',
                'irradiance' => 4.7,
                'peak_sun_hours' => 4.7,
                'efficiency_factor' => 0.83
            ),
            'batu_pahat' => array(
                'name' => 'Batu Pahat',
                'irradiance' => 4.7,
                'peak_sun_hours' => 4.7,
                'efficiency_factor' => 0.83
            ),
            'kluang' => array(
                'name' => 'Kluang',
                'irradiance' => 4.7,
                'peak_sun_hours' => 4.7,
                'efficiency_factor' => 0.83
            ),
            'muar' => array(
                'name' => 'Muar',
                'irradiance' => 4.7,
                'peak_sun_hours' => 4.7,
                'efficiency_factor' => 0.83
            ),
            'melaka' => array(
                'name' => 'Melaka',
                'irradiance' => 4.6,
                'peak_sun_hours' => 4.6,
                'efficiency_factor' => 0.81
            ),
            'johor' => array(
                'name' => 'Johor (Other Areas)',
                'irradiance' => 4.7,
                'peak_sun_hours' => 4.7,
                'efficiency_factor' => 0.83
            )
        );
    }
    
    private function init_tnb_rates() {
        // NEM/ATAP Solar Rates (February 2026)
        // When you import power at night, you pay for these components:
        $this->solar_rates = array(
            'import_rate' => array(
                'energy_charge' => 0.3703,      // RM/kWh - Energy component
                'capacity_charge' => 0.0455,    // RM/kWh - Capacity component
                'network_charge' => 0.1285,     // RM/kWh - Network component
                'forecast_afa' => -0.0499,      // RM/kWh - Rebate (February 2026)
                'total' => 0.4944               // RM/kWh - Total import rate
            ),
            'export_rate' => 0.3700,            // RM/kWh - Solar export offset rate (energy charge only)
            'price_gap' => 0.1244               // RM/kWh - Loss per kWh (RM 0.4944 - RM 0.3700 = RM 0.1244)
        );
        
        // Important: The "Price Gap"
        // - Export solar to grid: earn RM 0.37/kWh
        // - Import same energy back: pay RM 0.49/kWh  
        // - Net loss: RM 0.12/kWh by using grid as "battery"
        // - This is why physical batteries improve ROI significantly
        
        // TNB Electricity Tariff Rates (2025) - RM per kWh
        $this->tnb_rates = array(
            'tariff_a' => array(
                'name' => 'Domestic Tariff',
                'blocks' => array(
                    array('min' => 0, 'max' => 200, 'rate' => 0.218),
                    array('min' => 201, 'max' => 300, 'rate' => 0.334),
                    array('min' => 301, 'max' => 600, 'rate' => 0.516),
                    array('min' => 601, 'max' => 900, 'rate' => 0.546),
                    array('min' => 901, 'max' => PHP_INT_MAX, 'rate' => 0.571)
                ),
                'minimum_charge' => 3.00
            ),
            'tariff_b' => array(
                'name' => 'Low Voltage Commercial',
                'rate' => 0.365,
                'minimum_charge' => 7.20
            ),
            'tariff_c1' => array(
                'name' => 'Medium Voltage General Commercial',
                'rate' => 0.337,
                'demand_charge' => 30.30, // RM per kW
                'minimum_charge' => 600.00
            ),
            'tariff_c2' => array(
                'name' => 'Medium Voltage Peak/Off-Peak Commercial',
                'peak_rate' => 0.365,
                'off_peak_rate' => 0.224,
                'demand_charge' => 45.10, // RM per kW
                'minimum_charge' => 600.00,
                'peak_hours' => array(
                    array('start' => '08:00', 'end' => '22:00') // 8am-10pm weekdays
                )
            ),
            'tariff_d' => array(
                'name' => 'Low Voltage Industrial',
                'rate' => 0.365,
                'minimum_charge' => 7.20
            ),
            'tariff_ds' => array(
                'name' => 'Special Industrial Tariff',
                'rate' => 0.328,
                'minimum_charge' => 7.20
            ),
            'tariff_e1' => array(
                'name' => 'Medium Voltage General Industrial',
                'rate' => 0.329,
                'demand_charge' => 30.30,
                'minimum_charge' => 600.00
            ),
            'tariff_e2' => array(
                'name' => 'Medium Voltage Peak/Off-Peak Industrial',
                'peak_rate' => 0.356,
                'off_peak_rate' => 0.219,
                'demand_charge' => 45.10,
                'minimum_charge' => 600.00,
                'peak_hours' => array(
                    array('start' => '08:00', 'end' => '22:00')
                )
            ),
            'tariff_e2s' => array(
                'name' => 'Special Industrial Tariff (Peak/Off-Peak)',
                'peak_rate' => 0.320,
                'off_peak_rate' => 0.197,
                'demand_charge' => 45.10,
                'minimum_charge' => 600.00,
                'peak_hours' => array(
                    array('start' => '08:00', 'end' => '22:00')
                )
            ),
            'tariff_e3' => array(
                'name' => 'High Voltage Peak/Off-Peak Industrial',
                'peak_rate' => 0.346,
                'off_peak_rate' => 0.212,
                'demand_charge' => 42.00,
                'minimum_charge' => 600.00,
                'peak_hours' => array(
                    array('start' => '08:00', 'end' => '22:00')
                )
            )
        );
    }
    
    private function init_tariff_groups() {
        $this->tariff_groups = array(
            'tariff_a' => array(
                'name' => 'Tariff A - Domestic Tariff',
                'type' => 'domestic',
                'has_voltage_level' => true,
                'has_location' => true,
                'voltage_levels' => array('single_phase', 'three_phase'),
                'single_phase_cap' => 4,
                'three_phase_cap' => 10,
            ),
        );
    }
    
    public function get_tariff_groups() {
        return $this->tariff_groups;
    }
    
    public function get_solar_locations() {
        return $this->solar_irradiance;
    }
    
    private function calculate_monthly_consumption($monthly_bill) {
        $tariff = $this->tnb_rates['tariff_a'];
        $remaining_bill = max(0, $monthly_bill - $tariff['minimum_charge']);
        $consumption = 0;
        
        foreach ($tariff['blocks'] as $block) {
            $block_size = $block['max'] - $block['min'] + 1;
            if ($block['max'] === PHP_INT_MAX) {
                $block_size = 100000;
            }
            
            $block_cost = $block_size * $block['rate'];
            
            if ($remaining_bill >= $block_cost) {
                $consumption += $block_size;
                $remaining_bill -= $block_cost;
            } else {
                $consumption += $remaining_bill / $block['rate'];
                break;
            }
        }
        
        return max(0, $consumption);
    }
    
    private function get_allowed_payment_methods() {
        return array('cash', 'loan', 'credit_installment');
    }
    
    public function calculate_nem() {
        if (!check_ajax_referer('nem_calculator_nonce', 'nonce', false)) {
            wp_send_json_error(array(
                'message' => 'Security check failed. Please refresh the page and try again.'
            ), 403);
            return;
        }
        
        if (empty($_POST['monthly_bill'])) {
            wp_send_json_error(array(
                'message' => 'Please enter your monthly electricity bill.'
            ), 400);
            return;
        }
        
        try {
            $tariff_group = 'tariff_a';
            $max_demand = 0;
            $monthly_bill = isset($_POST['monthly_bill']) ? floatval(wp_unslash($_POST['monthly_bill'])) : 0;
            $mode_of_purchase = isset($_POST['mode_of_purchase']) ? sanitize_text_field(wp_unslash($_POST['mode_of_purchase'])) : '';
            $solar_rate = 0;
            $voltage_level = isset($_POST['voltage_level']) ? sanitize_text_field(wp_unslash($_POST['voltage_level'])) : '';
            $building_type = '';
            $location = isset($_POST['location']) ? sanitize_text_field(wp_unslash($_POST['location'])) : 'johor_bahru';
            $peak_percentage = 70;
        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => 'Invalid input data.'
            ), 400);
            return;
        }
        
        if ($monthly_bill <= 0) {
            wp_send_json_error(array(
                'message' => 'Monthly bill must be greater than zero.'
            ), 400);
            return;
        }
        
        if (!in_array($mode_of_purchase, $this->get_allowed_payment_methods(), true)) {
            wp_send_json_error(array(
                'message' => 'Please select a valid payment method.'
            ), 400);
            return;
        }
        
        if (!in_array($voltage_level, array('single_phase', 'three_phase'), true)) {
            wp_send_json_error(array(
                'message' => 'Please select a valid voltage level.'
            ), 400);
            return;
        }
        
        try {
            if (!isset($this->solar_irradiance[$location])) {
                wp_send_json_error(array(
                    'message' => 'Please select a supported location.'
                ), 400);
                return;
            }
            
            $location_data = $this->solar_irradiance[$location];
            $tariff_data = $this->tnb_rates['tariff_a'];
            
            $system_capacity = ($voltage_level === 'single_phase') ? 4 : 10;
            
            $daily_generation = $system_capacity * $location_data['peak_sun_hours'] * $location_data['efficiency_factor'];
            $monthly_generation = $daily_generation * 30;
            $monthly_consumption = $this->calculate_monthly_consumption($monthly_bill);
            
            $self_consumption = min($monthly_generation, $monthly_consumption);
            $export_to_grid = max(0, $monthly_generation - $monthly_consumption);
            $energy_rate = $this->solar_rates['import_rate']['total']; // RM 0.4944
            
            $self_savings = $self_consumption * $energy_rate;
            $export_earnings = $export_to_grid * $this->solar_rates['export_rate'];
            $monthly_savings = $self_savings + $export_earnings;
            
            $system_cost_per_watt = 4.50;
            $total_system_cost = $system_capacity * 1000 * $system_cost_per_watt;
            $annual_savings = $monthly_savings * 12;
            $payback_period = ($total_system_cost > 0 && $annual_savings > 0)
                ? ($total_system_cost / $annual_savings)
                : 0;
            
            $year_projections = array();
            $cumulative_savings = 0;
            $degradation_rate = 0.005;
            
            for ($year = 1; $year <= 25; $year++) {
                $year_efficiency = 1 - ($degradation_rate * ($year - 1));
                $year_generation = $monthly_generation * 12 * $year_efficiency;
                $year_savings = $year_generation * $energy_rate;
                $cumulative_savings += $year_savings;
                
                $year_projections[] = array(
                    'year' => $year,
                    'generation' => round($year_generation, 0),
                    'savings' => round($year_savings, 2),
                    'cumulative_savings' => round($cumulative_savings, 2),
                    'roi' => ($total_system_cost > 0) ? round(($cumulative_savings / $total_system_cost) * 100, 1) : 0
                );
            }
            
            $monthly_breakdown = array();
            for ($month = 1; $month <= 12; $month++) {
                $monthly_breakdown[] = array(
                    'month' => $month,
                    'generation' => round($monthly_generation, 0),
                    'savings' => round($monthly_savings, 2),
                    'consumption' => round($monthly_consumption, 0)
                );
            }
            
            $results = array(
                'system_capacity' => $system_capacity,
                'location_name' => $location_data['name'],
                'peak_sun_hours' => $location_data['peak_sun_hours'],
                'monthly_generation' => round($monthly_generation, 0),
                'monthly_consumption' => round($monthly_consumption, 0),
                'monthly_bill' => round($monthly_bill, 2),
                'monthly_savings' => round($monthly_savings, 2),
                'annual_savings' => round($annual_savings, 2),
                'energy_rate' => round($energy_rate, 3),
                'total_system_cost' => round($total_system_cost, 2),
                'payback_period' => round($payback_period, 1),
                'lifetime_savings' => round($cumulative_savings, 2),
                'year_projections' => $year_projections,
                'monthly_breakdown' => $monthly_breakdown,
                'tariff_type' => $tariff_data['name'],
                'has_peak_offpeak' => false,
                'peak_rate' => 0,
                'offpeak_rate' => 0,
                'voltage_info' => ($voltage_level === 'single_phase')
                    ? 'Single-phase meter (230V, 4 terminals), capped at 4kWac'
                    : 'Three-phase meter (415V, 8 terminals), capped at 10kWac',
                'nem_rates' => array(
                    'import_rate' => $this->solar_rates['import_rate']['total'],
                    'export_rate' => $this->solar_rates['export_rate'],
                    'price_gap' => $this->solar_rates['price_gap'],
                    'import_breakdown' => array(
                        'energy_charge' => $this->solar_rates['import_rate']['energy_charge'],
                        'capacity_charge' => $this->solar_rates['import_rate']['capacity_charge'],
                        'network_charge' => $this->solar_rates['import_rate']['network_charge'],
                        'forecast_afa' => $this->solar_rates['import_rate']['forecast_afa']
                    )
                ),
                'self_consumption' => round($self_consumption, 0),
                'export_to_grid' => round($export_to_grid, 0)
            );
            
            global $wpdb;
            $table_name = $wpdb->prefix . 'nem_calculations';
            
            $user_email = isset($_POST['user_email']) ? sanitize_email(wp_unslash($_POST['user_email'])) : null;
            $user_name = isset($_POST['user_name']) ? sanitize_text_field(wp_unslash($_POST['user_name'])) : null;
            $user_phone = isset($_POST['user_phone']) ? sanitize_text_field(wp_unslash($_POST['user_phone'])) : null;
            
            $inserted = $wpdb->insert(
                $table_name,
                array(
                    'user_email' => $user_email,
                    'user_name' => $user_name,
                    'user_phone' => $user_phone,
                    'tariff_group' => $tariff_group,
                    'location' => $location,
                    'voltage_level' => $voltage_level,
                    'building_type' => $building_type,
                    'max_demand' => $max_demand,
                    'monthly_bill' => $monthly_bill,
                    'mode_of_purchase' => $mode_of_purchase,
                    'solar_rate' => $solar_rate,
                    'peak_percentage' => $peak_percentage,
                    'system_capacity' => $system_capacity,
                    'monthly_generation' => round($monthly_generation, 0),
                    'monthly_savings' => round($monthly_savings, 2),
                    'annual_savings' => round($annual_savings, 2),
                    'payback_period' => round($payback_period, 1),
                    'lifetime_savings' => round($cumulative_savings, 2),
                    'user_ip' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '',
                    'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '',
                    'lead_status' => $user_email ? 'new' : 'anonymous'
                ),
                array(
                    '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%f', '%f', '%s', '%f', '%d',
                    '%f', '%d', '%f', '%f', '%f', '%f', '%s', '%s', '%s'
                )
            );
            
            if (false === $inserted && !empty($wpdb->last_error)) {
                error_log('NEM Calculator: Database insert failed.');
            }
            
            wp_send_json_success($results);
        
        } catch (Exception $e) {
            error_log('NEM Calculator: Calculation failed - ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => 'Unable to complete the calculation. Please review your inputs and try again.'
            ), 500);
        }
    }
}
